class Monstro {
  #vida;

  constructor(apelido, tipo, vidaInicial) {
    this.apelido = apelido;
    this.tipo = tipo;
    this.#vida = vidaInicial;
  }

  get vida() {
    return this.#vida;
  }

  sofrerDano(pontos) {
    this.#vida -= pontos;
    if (this.#vida < 0) {
      this.#vida = 0;
    }
    console.log(`${this.apelido} ficou com ${this.#vida} de vida`);
  }

  atacar(alvo) {
    console.log(`${this.apelido} ataca ${alvo.apelido}`);
    alvo.sofrerDano(10);
  }
}

class Dragao extends Monstro {
  constructor(apelido, vidaInicial) {
    super(apelido, 'Fogo', vidaInicial);
  }

  atacar(alvo) {
    console.log(`${this.apelido} solta uma baforada de fogo em ${alvo.apelido}`);
    alvo.sofrerDano(20);
  }
}

class Golem extends Monstro {
  constructor(apelido, vidaInicial) {
    super(apelido, 'Pedra', vidaInicial);
  }

  atacar(alvo) {
    console.log(`${this.apelido} joga uma pedra em ${alvo.apelido}`);
    alvo.sofrerDano(15);
  }
}

const dragao = new Dragao('Draco', 50);
const golem = new Golem('Rochoso', 30);

golem.atacar(dragao);
dragao.atacar(golem);
dragao.atacar(golem);

console.log(dragao.vida);
console.log(golem.vida);
