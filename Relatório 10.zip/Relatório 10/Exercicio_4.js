class Professor {
  constructor(nome) {
    this.nome = nome;
  }

  corrigir(aluno) {
    console.log(`${this.nome} corrige a prova de ${aluno.nome}`);
  }
}

class ProfessorExatas extends Professor {
  corrigir(aluno) {
    console.log(`${this.nome} confere os cálculos de ${aluno.nome}`);
  }
}

class ProfessorHumanas extends Professor {
  corrigir(aluno) {
    console.log(`${this.nome} lê a redação de ${aluno.nome}`);
  }
}

class ProfessorArtes extends Professor {
  corrigir(aluno) {
    console.log(`${this.nome} avalia o desenho de ${aluno.nome}`);
  }
}

class Aluno {
  constructor(nome, matricula) {
    this.nome = nome;
    this.matricula = matricula;
  }
}

class Turma {
  #alunos;

  constructor(sala, alunos = []) {
    this.sala = sala;
    this.#alunos = alunos;
  }

  listarAlunos() {
    console.log(`Sala ${this.sala}`);
    this.#alunos.forEach(a => console.log(`${a.matricula} - ${a.nome}`));
  }

  buscarAluno(matricula) {
    return this.#alunos.find(a => a.matricula === matricula);
  }
}

const aluno1 = new Aluno('Rafael', 101);
const aluno2 = new Aluno('Beatriz', 102);

const turma = new Turma('3B', [aluno1, aluno2]);
turma.listarAlunos();

const alvo = turma.buscarAluno(102);

const professores = [
  new ProfessorExatas('Helena'),
  new ProfessorHumanas('Marcos'),
  new ProfessorArtes('Sofia')
];

professores.forEach(p => p.corrigir(alvo));
