class Arma {
  constructor(modelo) {
    this.modelo = modelo;
  }
}

class Heroi {
  #arma;

  constructor(codinome, modeloDaArma) {
    this.codinome = codinome;
    this.#arma = new Arma(modeloDaArma);
  }

  usarPoder() {
    throw new Error('A classe filha precisa implementar usarPoder');
  }

  entrarNaLuta() {
    console.log(`${this.codinome} entra com ${this.#arma.modelo}: ${this.usarPoder()}`);
  }
}

class Mago extends Heroi {
  usarPoder() {
    return 'lança uma bola de fogo';
  }
}

class Arqueiro extends Heroi {
  usarPoder() {
    return 'dispara uma flecha dupla';
  }
}

class Guerreiro extends Heroi {
  usarPoder() {
    return 'bate com o escudo';
  }
}

class Guilda {
  #herois;

  constructor(nome, herois) {
    this.nome = nome;
    this.#herois = herois;
  }

  iniciarMissao() {
    console.log(`Guilda ${this.nome} começou a missão`);
    this.#herois.forEach(h => h.entrarNaLuta());
  }

  listarMagos() {
    return this.#herois.filter(h => h instanceof Mago);
  }
}

const mago1 = new Mago('Merlin', 'Cajado');
const mago2 = new Mago('Gandalf', 'Varinha');
const arqueiro = new Arqueiro('Legolas', 'Arco longo');
const guerreiro = new Guerreiro('Aragorn', 'Espada');

const guilda = new Guilda('Anel', [mago1, mago2, arqueiro, guerreiro]);
guilda.iniciarMissao();

guilda.listarMagos().forEach(m => console.log(m.codinome));

const generico = new Heroi('Teste', 'Faca');
