class Ficha {
  constructor(titulo, paginas) {
    this.titulo = titulo;
    this.paginas = paginas;
  }

  descrever() {
    return `${this.titulo} tem ${this.paginas} páginas`;
  }
}

class Catalogo {
  #fichas;

  constructor(numero) {
    this.numero = numero;
    this.#fichas = [];
  }

  anotar(titulo, paginas) {
    const ficha = new Ficha(titulo, paginas);
    this.#fichas.push(ficha);
  }

  exibirFichas() {
    console.log(`Catálogo número ${this.numero}`);
    this.#fichas.forEach(f => console.log(f.descrever()));
  }
}

class Bibliotecario {
  constructor(nome, turno) {
    this.nome = nome;
    this.turno = turno;
  }
}

class Biblioteca {
  #bibliotecarios;

  constructor(dono) {
    this.dono = dono;
    this.#bibliotecarios = [];
  }

  contratar(bibliotecario) {
    this.#bibliotecarios.push(bibliotecario);
  }

  abrirAsPortas() {
    console.log(`Biblioteca de ${this.dono} aberta`);
    this.#bibliotecarios.forEach(b => console.log(`${b.nome} - ${b.turno}`));
  }
}

const catalogo = new Catalogo(7);
catalogo.anotar('Dom Casmurro', 256);
catalogo.anotar('O Cortiço', 300);
catalogo.anotar('Iracema', 120);
catalogo.exibirFichas();

const bibliotecario1 = new Bibliotecario('Clara', 'Manhã');
const bibliotecario2 = new Bibliotecario('Paulo', 'Tarde');

const biblioteca = new Biblioteca('Seu Antônio');
biblioteca.contratar(bibliotecario1);
biblioteca.contratar(bibliotecario2);
biblioteca.abrirAsPortas();
